find $1 -name $2 -type f -exec grep -l $3 {} \;
