namespace Classes; //ta razred spodaj dodamo v namespace, da logicno organiziramo kodo

public class BankAccount{ //ustvarimo razred
    public string Account { get; set; }  //tole je property, z get/set poves ali se da ta property get-at/set-at

    public string Number { get; }
    public string Owner { get; set; }
    //public decimal Balance { get; }

    public decimal Balance { //balance = vsota amount-ov
        get {
            decimal balance = 0;
            foreach (var item in _allTransactions){ //foreach cez nek iterable
                balance += item.Amount;
            }
            return balance;
        }
    } //kaj kle vidimo? vsakic ko klices BankAccount.Balance, se namesto neke fiksne vrednosti klice funkcija (v tem primeru get) in s tem racunas Balance

    private static int s_accountNumberSeed = 1234567890; //c# naming convention: s_ pomeni static private, static pomeni da je vrednost te spremenljivke enaka pri vseh objektih razreda

    private List<Transaction> _allTransactions = new List<Transaction>(); //ustvarimo tabelo razredov

    public void MakeDeposit(decimal amount, DateTime date, string note){
        if (amount <= 0){
            throw new ArgumentOutOfRangeException(nameof(amount), "Amount of deposit must be positive"); //uporaba exception-ov
        }
        var deposit = new Transaction(amount, date, note);
        _allTransactions.Add(deposit); //dodajanje elementov v seznam
    }

    public void MakeWithdrawal(decimal amount, DateTime date, string note){
        if (amount <= 0){
            throw new ArgumentOutOfRangeException(nameof(amount), "Amount of withdrawal must be positive");
        }
        if (Balance - amount < 0){
            throw new InvalidOperationException("Not sufficient funds for this withdrawal");
        }
        var withdrawal = new Transaction(-amount, date, note);
        _allTransactions.Add(withdrawal);
    }

    public BankAccount(string name, decimal initialBalance){   //konstruktor, izvede ob klicu razreda
        this.Owner = name;
        Number = s_accountNumberSeed.ToString();
        s_accountNumberSeed++;
        MakeDeposit(initialBalance, DateTime.Now, "Initial balance");
    }

    public string GetAccountHistory(){
        var report = new System.Text.StringBuilder();
        decimal balance = 0;
        report.AppendLine("Date\t\tAmount\tBalance\tNote");
        foreach (var item in _allTransactions){
            balance += item.Amount;
            report.AppendLine($"{item.Date.ToShortDateString()}\t{item.Amount}\t{balance}\t{item.Notes}");
        }
        return report.ToString();
    }

}

//member-ji razreda: to so properties (lastnosti) ter methods (metode)