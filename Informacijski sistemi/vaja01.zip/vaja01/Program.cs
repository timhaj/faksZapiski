﻿using Classes;   //dodamo namespace, da lahko reference-amo druge lastno definirane razrede

var account = new BankAccount("Tim Hajdinjak", 1250);   //kreiramo nov objekt razreda
Console.WriteLine($"Account {account.Number} was created for {account.Owner} with {account.Balance} initial balance.");   //izpis  //$ pred oklepaji pomeni formatiran string

account.MakeWithdrawal(500, DateTime.Now, "Kupu AVAX in BEAM");
Console.WriteLine(account.Balance);
account.MakeDeposit(100, DateTime.Now, "Stipendija");
Console.WriteLine(account.Balance);

Console.WriteLine(account.GetAccountHistory());

//DateTime.Now vrne trenutni datum in cas
//Console.WriteLine izpise v konzolo

// primer uporabe try/catch bloka
BankAccount invalidAccount;
try{
    invalidAccount = new BankAccount("invalid", -55);
}
catch (ArgumentOutOfRangeException e){
    Console.WriteLine("Exception caught creating account with negative balance");
    Console.WriteLine(e.ToString());
    return;
}

//in se en primer
try{
    account.MakeWithdrawal(750, DateTime.Now, "Attempt to overdraw");
}
catch (InvalidOperationException e){
    Console.WriteLine("Exception caught trying to overdraw");
    Console.WriteLine(e.ToString());
}