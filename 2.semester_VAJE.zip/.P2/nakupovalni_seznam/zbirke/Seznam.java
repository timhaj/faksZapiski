package zbirke;

public class Seznam {
    private static String[] arr;

    private static int n = 0;

    /**
     * Opis funkcije: ustvari nov seznam, ki še ne obstaja
     * @param n dolžina seznama
     * @return True, če seznam še ne obstaja, drugače false
     */
    public static boolean narediSeznam(int n){
        if(arr != null){
            return false;
        }
        arr = new String[n];
        return true;
    }

    /**
     * Opis funkcije: dodamo nov element na konec seznama
     * @param element ki ga dodajamo v seznam
     * @return true, če je bil element uspešno dodan, false v primeru če seznam ne obstaja ali pa je seznam že poln
     */
    public static boolean dodajNaKonecSeznama(String element){
        if(arr == null || n == arr.length){
            return false;
        }
        else{
            arr[arr.length-1] = element;
            n++;
            return true;
        }
    }

    /**
     * Opis funkcije: izpise celoten seznam
     */
    public static void izpisiSeznam(){
        if(arr == null){
            System.out.println("NAPAKA: Seznam ne obstaja.");
        }
        else if(n == 0){
            System.out.println("Seznam je prazen (nima elementov).");
        }
        else{
            System.out.println("Na seznamu so naslednji elementi: ");
            int temp = 1;
            for(int i = 1;i<=arr.length;i++){
                if(arr[i-1] != null) {
                    System.out.printf("%d: %s\n", temp, arr[i - 1]);
                    temp++;
                }
            }
        }
    }

    /**
     *
     * @param mesto elementa ki ga hočemo izbrisat
     * @return vrne element, ki smo ga izbrisali, null v primeru če mesto kaže na neobstoječi element
     */
    public static String odstraniIzSeznama(int mesto){
        if(arr[mesto-1] == null){
            return null;
        }
        else{
            String zaRet = arr[mesto-1];
            n--;
            arr[mesto-1] = null;
            String tmp[] = new String[n];
            int temp = 0;
            if(n != 0){
                for(int i = 0;i<arr.length;i++){
                    if(arr[i] != null){
                        tmp[temp] = arr[i];
                        temp++;
                    }
                }
                arr = tmp;
            }
            return zaRet;
        }
    }

    /**
     *
     * @param element ki ga dodajamo
     * @param mesto elementa, kamor ga hočemo dodati
     * @return true, če je bil element dodan, false v primerih, če je mesto neveljavno, seznam ne obstaja ali je seznam že poln
     */
    public static boolean dodajVSeznam(String element, int mesto){
        if(arr == null || n == arr.length || mesto <= 0){
            return false;
        }
        else if(mesto > arr.length){
            arr[arr.length-1] = element;
            n++;
            return true;
        }
        else{
            String tmp[] = new String[arr.length];
            int j = 0;
            for(int i = 0;i<arr.length;i++){
                if(i == (mesto - 1)){
                    tmp[i] = element;
                }
                else{
                    tmp[i] = arr[j];
                    j++;
                }
            }
            arr = tmp;
            n++;
            return true;
        }
    }

    /**
     * Opis funkcije: vrne dolžino seznama
     * @return Vrne dolžino seznama, če pa ne obstaja, vrne -1
     */
    public static int dolzinaSeznama(){
        if(arr == null){
            return -1;
        }
        return arr.length;
    }

    /**
     * Opis funkcije: uniči že obstoječi seznam
     * @return True, če seznam obstaja, drugače vrne false
     */
    public static boolean uniciSeznam(){
        if(arr == null){
            return false;
        }
        arr = null;
        n = 0;
        return true;
    }

    public static void main(String[] args) {

    }
}
