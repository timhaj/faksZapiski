package predavanje02;

public class JavaZakon {
    public static void main(String[] args) {
        System.out.println("1. Java je zakon!");
        System.out.println("2. Java je zakon!");
        System.out.println("3. Java je zakon!");
        System.out.println("4. Java je zakon!");
        System.out.println("5. Java je zakon!");
    }
}
