package predavanje02;

public class JavaZakonFor {
        public static void main(String[] args) {
            for (int i = 1;  i <= 5; i = i + 1) {
                System.out.println(i + ". Java je zakon!");
            }
        }
}
