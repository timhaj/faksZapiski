package predavanje10;

interface Funkcija {
    public double vrednost(double x);
    public double odvod(double x);
}
