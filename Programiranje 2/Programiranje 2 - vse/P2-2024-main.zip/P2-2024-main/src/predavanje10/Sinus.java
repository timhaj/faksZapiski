package predavanje10;

public class Sinus implements Funkcija {
  @Override
  public double vrednost(double x) {
    return 0;
  }

  @Override
  public double odvod(double x) {
    return 0;
  }
}
