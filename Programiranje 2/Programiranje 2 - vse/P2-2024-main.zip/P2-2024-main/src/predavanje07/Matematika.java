package predavanje07;

public class Matematika {
  static final double PHI = 1.681;

  static int kvadrat(int x) {
    return x*x;
  }
}
