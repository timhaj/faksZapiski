package predavanje09;

public class Oseba {
  String ime;

  Oseba(String ime) {
    this.ime = ime;
  }
  public void izpisi() {
    System.out.println(ime);
  }
}
