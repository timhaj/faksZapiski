package predavanje09;

abstract public class Funkcija {
  abstract public double vrednost(double x);
  abstract public double odvod(double x);
}
