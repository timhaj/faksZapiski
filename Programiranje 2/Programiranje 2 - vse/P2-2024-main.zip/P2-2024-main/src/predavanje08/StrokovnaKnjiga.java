package predavanje08;

public class StrokovnaKnjiga extends Knjiga {
  private String index;

  public void setIndex(String index) {
    this.index = index;
  }
  public String getIndex() {
    return this.index;
  }
}
