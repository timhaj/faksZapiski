package predavanje08;

public class Oseba {
  public String ime;

  public void izpisi() {
    System.out.println("Oseba: " + ime);
  }
}
