package predavanje08;

public class Leposlovje extends Knjiga {
  String[] mnenja;
  int      stMnenj;
}
